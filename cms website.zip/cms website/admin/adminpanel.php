<?php
session_start();
if(!$_SESSION["user_name"])
{header('location:login.php?error=you are not an administrator');
}
?>
<html>
<head><title>admin panel</title></head>
<body>

<div style="width:100%;background:red;height:100px;text-align:center;font-size:33px">welcome to admin panel!</div>
welcome:<font size="4" color="red">
<?php $_SESSION["user_name"];?></font>
<h2 align='center'><?php echo @$_GET["deleted"];?></h2>
<h2><a href="adminpanel.php?view_page=view page">view pages</a></h2>
<h2><a href="insert_page.php">insert new page</a></h2>
<h2><a href="insert_menu.php">insert new menu</a></h2>
<h2><a href="adminpanel.php?view_menu=view menu">view menus</a></h2>
<h2><a href="logout.php">logout</a></h2>
<?php
if(isset($_GET['view_page']))
{
?>
<table width='1000'border='2' align='center'>
<tr>
<td align='center' bgcolor='yellow' colspan='6'><h2>all pages here!</h2></td>
</tr>
<tr align='center'>
<th>page no:</th>
<th>page title:</th>
<th>page content:</th>
<th>delete</th>
</tr>
<tr>
<?php include("../include/db.php");
$query="select * from pages";
$run=mysql_query($query);
if (!$run) {
    echo "Could not successfully run query ($query) from DB: " . mysql_error();
    exit;
}

while($row=mysql_fetch_array($run))
{$p_id=$row["p_id"];
$p_title=$row["p_title"];
$p_desc=$row["p_desc"];
?>
<td><?php echo $p_id;?></td>
<td><?php echo $p_title;?></td>
<td><?php echo $p_desc;?></td>
<td><a href="delete_page.php?del_page=<?php echo $p_id?>"> delete </a></td>
</tr>
<?php }}?>
</table>
<?php
if(isset($_GET['view_menu']))
{
?>
<table width='400' border='3' align='center'>
<tr>
<td colspan='5' bgcolor='aqua' align='center'><h2>all menus here</h2> </td>
</tr>
<tr align='center'>
<th>menu no:</th>
<th>menu title:</th>
<th>delete</th>
</tr>
<tr>
<?php include("../include/db.php");
$query="select * from menus";
$run=mysql_query($query);
while($row=mysql_fetch_array($run))
{$m_id=$row['m_id'];
$m_title=$row['m_title'];
?>
<td><?php echo $m_id;?></td>
<td><?php echo $m_title;?></td>
<td><a href="delete_menu.php?del_menu=<?php echo $m_id; ?>">delete</a></td>
</tr>
<?php }}?>
</table>
</body>
</html>