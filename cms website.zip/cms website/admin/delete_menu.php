<?php
include("../include/db.php");
include("adminpanel.php");
$delete_menu=$_GET['del_menu'];
$query="delete from menus where m_id=$delete_menu";
if(mysql_query($query))
{
	echo "<script>window.open('adminpanel.php?deleted=a menu has been deleted','_self')</script>";
}
else
{
    echo "Could not successfully run query ($query) from DB: " . mysql_error();
    exit;
}
?>