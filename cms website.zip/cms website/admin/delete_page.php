<?php
include("../include/db.php");
include("adminpanel.php");
$delete_page=$_GET['del_page'];
$query="delete from pages where p_id=$delete_page";
if(mysql_query($query))
{
	echo"<script>window.open('adminpanel.php?deleted=a page has been deleted','_self') </script>";
}
?>