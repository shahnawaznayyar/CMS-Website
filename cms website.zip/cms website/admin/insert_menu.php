<?php
session_start();
?>
<html>
<?php
include("../include/db.php");
include("adminpanel.php");
?>
<form type="" method="post">
<table width="400" border="10" align="center">
<tr><td align="center" bgcolor="orange" colspan="4"><h2>insert new menu here!</h2></td>
</tr>
<tr>
<th>menu title</th>
<td><input type="text" name="menu_title"></td>
</tr>
<tr>
<td align="center"><input type="submit" name="submit" value="submit"></td>
</tr>
</table>
</form>
</html>
<?php
if(isset($_POST['submit']))
{$menu_title=$_POST['menu_title'];
$query="insert into menus (m_title) values('$menu_title')";
if(mysql_query($query))
{
	echo"<script>window.open('adminpanel.php?inserted=a new menu has been inserted','_self')</script>";
}
	
}
?>