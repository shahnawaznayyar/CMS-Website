<?php
session_start();
?>
<html>
<form method="post">
<table width='500' border='3' align='center'>
<tr>
<td align='center' bgcolor='pink' colspan='4' ><h2>insert  new page here!</h2></td>
</tr>
<tr>
<th>page title</th>
<td><input type="text" name="page_title"></td>
</tr>
<tr>
<th>page content</th>
<td><textarea name="page_content" cols="20" rows="20"></textarea></td>
</tr>
<tr>
<td align ="center" colspan="5"><input type="submit" name="submit" value="submit">
</td>
</tr>
</table>
</form>
</html>
<?php
include("../include/db.php");
include("adminpanel.php");
if(isset ($_POST["submit"]))
{$page_title=$_POST["page_title"];
$page_content=$_POST["page_content"];
$query="insert into pages(p_title,p_desc) values('$page_title','$page_content')";
$run=mysql_query($query);
if($run)
{
	echo "<script>window.open('adminpanel.php?inserted=a new page has been inserted','_self')
</script>";
}
else
{ 
    echo "Could not successfully run query ($query) from DB: " . mysql_error();
    exit;
}	
}
?>