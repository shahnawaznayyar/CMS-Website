<?php
session_start();
?>
<html>
<head>
<title>admin login</title>
</head>
<body>
<form action="" method="post">
<?phpecho $GET['logout'];?>
<table align="center" width="400" border="4">
<tr><td bgcolor="green" align="center"colspan="5">admin login</td></tr>
<td>username:</td>
<td align="right"><input type="text" name="user_name" value=""></td>
</tr>
<tr>
<td align="right">password:</td>
<td><input type="password" name="user_pass" value=""></td>
</tr>
<tr>
<td align="center" colspan="5"><input type="submit" name="submit" value="submit"</td>
</tr>
</table>
</form>
</body>
</html>
<?php
include("../include/db.php");
if(isset($_POST["submit"]))
{$admin_name=$_SESSION["user_name"]=$_POST["user_name"];
$admin_pass=$_POST["user_pass"];
$query="select* from admin_login where user_name='$admin_name' AND user_pass='$admin_pass'";
$run=mysql_query($query);
if(mysql_num_rows($run)==1)
{echo"<script>window.open('adminpanel.php'?logged=you are logged in successfully,'
_self')</script>";
}
else
{
	echo"<script>alert('your password or username is incorrect')</script>";
}
else
{ 
    echo "Could not successfully run query ($query) from DB: " . mysql_error();
    exit;
}	
}
?>