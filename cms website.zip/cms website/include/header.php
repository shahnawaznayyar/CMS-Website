<html>
<body>
<table width='1000' border='0' align='center'>
<tr>
<td bgcolor='blue' height='100' align='center'><h1>welcome to our php website</h1></td>
</tr>
</table>
</body>
</html>