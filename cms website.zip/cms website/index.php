<html>
<head><title>basic cms </title>
<style type="text/css">
a:link{
	color:white;
	text-decoration:none;
	
}

</style>
</head>
<body>
<table border='2' width='1000' align='center'>
<!__header starts__>
<tr>
<td><?php include("include/header.php");
?>
</td>
</tr>
<!__navigation starts__>
<tr>
<td>
<table border='0'>
<tr>
<?php include("include/db.php");
$query="select * from menus";
$run=mysql_query($query);
while($row=mysql_fetch_array($run))
{
$m_title=$row[1];
echo "<td width='100' bgcolor='black' align ='center'><a href='pages.php?pages=$m_title'>$m_title</a></td>";
}

?>
</tr>
</table>
</td>
</tr>
<!__main content starts__>
<tr>
<td bgcolor='pink' height='500' valign='top'>
<h2>welcome to our website</h2>
<p>this website is for all users who want to learn php with its advance level and
 we are a team of developers,designers and 
SEO optimizers,who r working for last 3 years online
and have huge experience and knowledge of these subjects</p>
<p>this website is for all users who want to learn php with its advance level and
 we are a team of developers,designers and 
SEO optimizers,who r working for last 3 years online
and have huge experience and knowledge of these subjects</p>
<center><img src="chrysanthemum.jpg"</center></td>
</tr>
<!__footer starts__>
<tr>
<td bgcolor='black' height='40' align='center'><h1 style="color:white">created by shahnawaz nayyar</h1></td>
</tr>
</table>

</body>
</html>