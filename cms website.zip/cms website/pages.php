<html>
<head><title>basic cms </title>
<style type="text/css">
a:link{
	color:white;
	text-decoration:none;
	
}
a:visited{
	color:white;
}

</style>
</head>
<body>
<table border='2' width='1000' align='center'>
<!__header starts__>
<tr>
<td><?php include("include/header.php");
?>
</td>
</tr>
<!__navigation starts__>
<tr>
<td>
<tr>
<table border='0'>
<?php include("include/db.php");
$query="select * from menus";
$run=mysql_query($query);
while($row=mysql_fetch_array($run))
{
$m_title=$row[1];
echo "<td width='100' bgcolor='black' align ='center'><a href='pages.php?pages=$m_title'>$m_title</a></td>";
}

?>
</tr>
</table>
</td>
</tr>
<!__main content starts__>
<tr>
<td>
<table width='800' border='0' align='center'>
<tr>
<?php
$page=$_GET["pages"];
$query="select * from pages where p_title='$page'";
$run=mysql_query($query);
if (!$run) {
    echo "Could not successfully run query ($query) from DB: " . mysql_error();
    exit;
}
while($row=mysql_fetch_assoc($run))
{echo "<td bgcolor='blue'>"."<h2>".$row["p_title"]."</h2>".$row["p_desc"]."</td>";
}
?>
</tr>
</table>
</td>
</tr>
<!__footer starts__>
<tr>
<td bgcolor='black' height='40' align='center'><h1 style="color:white">created by shahnawaz nayyar</h1></td>
</tr>
</table>

</body>
</html>